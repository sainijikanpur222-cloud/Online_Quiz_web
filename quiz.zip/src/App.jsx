
import { useState } from "react";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import Quiz from "./components/Quiz";
import Result from "./components/Result";
import "./App.css";

function App() {
  const [userName, setUserName] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [resultData, setResultData] = useState(null);

  function handleLogout() {
    setUserName("");
    setSelectedSubject("");
    setResultData(null);
  }

  function handleRestart() {
    setResultData(null);
  }

  return (
    <>
      {userName === "" ? (
        <Login onLogin={setUserName} />
      ) : resultData ? (
        <Result
          resultData={resultData}
          onBack={() => {
            setResultData(null);
            setSelectedSubject("");
          }}
          onRestart={handleRestart}
        />
      ) : selectedSubject === "" ? (
        <Dashboard
          userName={userName}
          onSelectSubject={setSelectedSubject}
          onLogout={handleLogout}
        />
      ) : (
        <Quiz
          key={selectedSubject}
          subject={selectedSubject}
          onSubmit={setResultData}
          onBack={() => setSelectedSubject("")}
        />
      )}
    </>
  );
}

export default App;
