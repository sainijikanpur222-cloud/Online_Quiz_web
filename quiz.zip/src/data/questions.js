
const questions = {
  HTML: [
    {
      question: "Which tag is used to create a button in HTML?",
      options: ["<input>", "<button>", "<click>", "<btn>"],
      answer: 1
    },
    {
      question: "Which tag is used to create a checkbox?",
      options: [
        '<input type="check">',
        "<check>",
        '<input type="checkbox">',
        "<checkbox>"
      ],
      answer: 2
    },
    {
      question: "Which tag is used to create a dropdown list?",
      options: ["<select>", "<dropdown>", "<optionlist>", "<list>"],
      answer: 0
    },
    {
      question: "Which tag is used to define the title of a webpage?",
      options: ["<body>", "<title>", "<headings>", "<h1>"],
      answer: 1
    },
    {
      question: "Which tag is used to play audio in HTML5?",
      options: ["<sound>", "<music>", "<audio>", "<mp3>"],
      answer: 2
    },
    {
      question: "Which tag is used to play a video in HTML5?",
      options: ["<movie>", "<video>", "<media>", "<play>"],
      answer: 1
    },
    {
      question: "Which attribute is used to apply CSS directly to an HTML element?",
      options: ["class", "style", "font", "design"],
      answer: 1
    },
    {
      question: "Which tag is used to make text bold in HTML?",
      options: ["<b>", "<i>", "<u>", "<p>"],
      answer: 0
    },
    {
      question: "Which tag is used to create a horizontal line?",
      options: ["<line>", "<br>", "<hr>", "<hl>"],
      answer: 2
    },
    {
      question: "Which attribute specifies a unique identifier for an HTML element?",
      options: ["class", "name", "id", "type"],
      answer: 2
    }
  ],

  Math: [
    {
      question: "What is 15 + 25?",
      options: ["30", "40", "45", "50"],
      answer: 1
    },
    {
      question: "What is 12 × 8?",
      options: ["84", "92", "96", "108"],
      answer: 2
    },
    {
      question: "What is the square of 9?",
      options: ["18", "72", "81", "99"],
      answer: 2
    },
    {
      question: "What is 100 ÷ 4?",
      options: ["20", "25", "30", "40"],
      answer: 1
    },
    {
      question: "What is 20% of 200?",
      options: ["20", "30", "40", "50"],
      answer: 2
    },
    {
      question: "What is the value of 5²?",
      options: ["10", "15", "20", "25"],
      answer: 3
    },
    {
      question: "What is the next number: 2, 4, 6, 8, __?",
      options: ["9", "10", "12", "14"],
      answer: 1
    },
    {
      question: "What is half of 250?",
      options: ["100", "115", "125", "150"],
      answer: 2
    },
    {
      question: "What is the perimeter of a square with a side of 5 cm?",
      options: ["10 cm", "15 cm", "20 cm", "25 cm"],
      answer: 2
    },
    {
      question: "What is the average of 10, 20, and 30?",
      options: ["15", "20", "25", "30"],
      answer: 1
    }
  ],

  Python: [
    {
      question: "Who created Python?",
      options: [
        "James Gosling",
        "Guido van Rossum",
        "Dennis Ritchie",
        "Mark Zuckerberg"
      ],
      answer: 1
    },
    {
      question: "Which symbol is used for comments in Python?",
      options: ["//", "<!-- -->", "#", "**"],
      answer: 2
    },
    {
      question: "Which function is used to display output in Python?",
      options: ["show()", "print()", "displayText()", "output()"],
      answer: 1
    },
    {
      question: "Which data type stores text in Python?",
      options: ["int", "float", "str", "bool"],
      answer: 2
    },
    {
      question: "What is the output of print(5 + 3)?",
      options: ["53", "8", "2", "Error"],
      answer: 1
    },
    {
      question: "Which keyword is used to define a function?",
      options: ["function", "fun", "def", "define"],
      answer: 2
    },
    {
      question: "Which data type stores True or False?",
      options: ["int", "bool", "str", "list"],
      answer: 1
    },
    {
      question: "Which brackets are used to create a list in Python?",
      options: ["{}", "()", "[]", "<>"],
      answer: 2
    },
    {
      question: "What is the output of print(10 // 3)?",
      options: ["3.33", "3", "1", "0"],
      answer: 1
    },
    {
      question: "Which keyword is used for a condition in Python?",
      options: ["if", "for", "def", "print"],
      answer: 0
    }
  ],

  React: [
    {
      question: "What is React?",
      options: [
        "A database",
        "A JavaScript library",
        "An operating system",
        "A programming language"
      ],
      answer: 1
    },
    {
      question: "Who developed React?",
      options: ["Google", "Microsoft", "Facebook (now Meta)", "Amazon"],
      answer: 2
    },
    {
      question: "Which language is mainly used with React?",
      options: ["Java", "Python", "JavaScript", "C"],
      answer: 2
    },
    {
      question: "What is JSX?",
      options: [
        "A database",
        "A syntax extension for JavaScript",
        "A CSS framework",
        "An operating system"
      ],
      answer: 1
    },
    {
      question: "Which hook is used to manage state in a functional component?",
      options: ["useEffect", "useState", "useHTML", "useClass"],
      answer: 1
    },
    {
      question: "Which method is used to render a list of elements in React?",
      options: ["filter()", "map()", "push()", "join()"],
      answer: 1
    },
    {
      question: "What is a React component?",
      options: [
        "A reusable part of the user interface",
        "A database table",
        "A CSS property",
        "A browser"
      ],
      answer: 0
    },
    {
      question: "Which hook is commonly used for side effects in React?",
      options: ["useState", "useEffect", "useStyle", "usePage"],
      answer: 1
    },
    {
      question: "What is the purpose of props in React?",
      options: [
        "To pass data to components",
        "To create a database",
        "To write CSS",
        "To stop the application"
      ],
      answer: 0
    },
    {
      question: "Which syntax is used to embed a JavaScript expression in JSX?",
      options: ["()", "[]", "{}", "<>"],
      answer: 2
    }
  ]
};

export default questions;
