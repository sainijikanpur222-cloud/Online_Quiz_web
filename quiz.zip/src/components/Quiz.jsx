
import { useState } from "react";
import questions from "../data/questions";

function Quiz({ subject, onSubmit, onBack }) {
  const quizQuestions = questions[subject] || [];
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});

  if (quizQuestions.length === 0) {
    return <p>No questions available.</p>;
  }

  const question = quizQuestions[current];

  function selectAnswer(index) {
    setAnswers({
      ...answers,
      [current]: index
    });
  }

  function submitQuiz() {
    onSubmit({
      subject,
      questions: quizQuestions,
      answers
    });
  }

  return (
    <div className="quiz-page">
      <nav className="navbar">
        <h2>Online Quiz</h2>
        <button onClick={onBack}>Back</button>
      </nav>

      <div className="quiz-card">
        <h2>{subject} Quiz</h2>

       <p className="progress">
  Question {current + 1} of {quizQuestions.length}
</p>

        <div className="progress-track">
          <div
            className="progress-fill"
            style={{
              width: `${((current + 1) / quizQuestions.length ) * 100}%`
            }}
          />
        </div>

        <h3>{current + 1}. {question.question}</h3>

        <div className="options">
          {question.options.map((option, index) => (
            <label
              className={`option ${
                answers[current] === index ? "selected" : ""
              }`}
              key={index}
            >
              <input
                type="radio"
                name={`question-${current}`}
                checked={answers[current] === index}
                onChange={() => selectAnswer(index)}
              />
              {option}
            </label>
          ))}
        </div>

      
<div className="quiz-buttons">
  <button
    onClick={() => setCurrent(current - 1)}
    disabled={current === 0}
  >
    ← Previous
  </button>

  {current < quizQuestions.length - 1 ? (
    <button onClick={() => setCurrent(current + 1)}>
      Next →
    </button>
  ) : (
    <button onClick={submitQuiz}>
      Submit Quiz
    </button>
  )}
</div>

      </div>
    </div>
  );
}

export default Quiz;
