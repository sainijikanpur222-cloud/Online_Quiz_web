
function Result({ resultData, onBack, onRestart }) {
  const { subject, questions, answers } = resultData;

  const score = questions.reduce((total, question, index) => {
    return total + (answers[index] === question.answer ? 1 : 0);
  }, 0);

  const correct = score;
  const incorrect = questions.length - score;
  const percentage = Math.round((score / questions.length) * 100);

  return (
    <div className="result-page">
      <nav className="navbar">
        <h2>Online Quiz</h2>
        <button onClick={onBack}>Dashboard</button>
      </nav>

      <div className="result-card">
        <h1>Quiz Result</h1>
        <p>{subject} Quiz Completed!</p>

        <div className="score-circle">
          <h2>{score}/{questions.length}</h2>
          <p>{percentage}%</p>
        </div>

        <div className="result-stats">
          <div>
            <h3>{correct}</h3>
            <p>Correct Answers</p>
          </div>

          <div>
            <h3>{incorrect}</h3>
            <p>Wrong / Unanswered</p>
          </div>
        </div>

        <h2 className="review-title">Answer Review</h2>

        {questions.map((question, index) => (
          <div className="review-item" key={index}>
            <h4>
              {index + 1}. {question.question}
            </h4>

            <p>
              Your Answer:{" "}
              {answers[index] === undefined
                ? "Not Answered"
                : question.options[answers[index]]}
            </p>

            <p className="correct-answer">
              Correct Answer: {question.options[question.answer]}
            </p>

            <p className={
              answers[index] === question.answer ? "right" : "wrong"
            }>
              {answers[index] === question.answer
                ? "Correct"
                : "Incorrect"}
            </p>
          </div>
        ))}

       
<div className="result-buttons">
  <button onClick={onBack}>
    ← Back to Dashboard
  </button>

  <button onClick={onRestart}>
    ↻ Restart Quiz
  </button>
</div>

      </div>
    </div>
  );
}

export default Result;
