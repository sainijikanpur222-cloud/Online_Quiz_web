
function Dashboard({ userName, onSelectSubject, onLogout }) {
  const subjects = [
    { name: "HTML", icon: "🌐", description: "Test your HTML knowledge" },
    { name: "React", icon: "⚛️", description: "Test your React knowledge" },
    { name: "Python", icon: "🐍", description: "Test your Python knowledge" },
    { name: "Math", icon: "🧮", description: "Test your Math skills" }
  ];

  return (
    <div className="dashboard">
      <nav className="navbar">
        <h2>Online Quiz</h2>
        <button onClick={onLogout}>Logout</button>
      </nav>

      <div className="dashboard-content">
        <h1>Welcome, {userName}!</h1>
        <p>Select a subject to start your quiz.</p>

        <div className="subject-grid">
          {subjects.map((subject) => (
            <div className="subject-card" key={subject.name}>
              <div className="subject-icon">{subject.icon}</div>
              <h2>{subject.name}</h2>
              <p>{subject.description}</p>

              <button onClick={() => onSelectSubject(subject.name)}>
                Start Quiz
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
